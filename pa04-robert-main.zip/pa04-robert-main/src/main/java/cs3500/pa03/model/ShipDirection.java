package cs3500.pa03.model;

/**
 * an enumeration of the possible ship directions
 */
public enum ShipDirection {
  //one possible orientation being vertical
  VERTICAL,
  //another possible orientation being horizontal
  HORIZONTAL
}
